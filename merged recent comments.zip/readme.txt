=== Merged Recent Comments ===
Tags: polylang,wpml,merged
Requires at least: 3.4.0
Tested up to: 4.4.1
License: GPL-2.0+
Author: Patryk Ostrzo�ek

Merged Comments wrapped in current language.

== Description ==
This widget merges recent comments and wraps them in current language titles and links. This requires \'WPML merged comments plugin\' for proper working. Plugin is compatible with PolyLang and WPML.

== Installation ==
1. Upload .zip
2. Activate
3. Go to widget section and add Merged Recent Comments.